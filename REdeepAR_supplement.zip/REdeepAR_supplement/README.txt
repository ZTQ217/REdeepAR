--requirements.txt is the environment required in this project.
--000001.SZall(1).csv is the data analysed in Section 4 in the article.
--run methodcompare_arima.py, methodcompare_stationay.py and methodcompare_assequence.py and get the results in Fig.2, Table1, Table2 and Table A1 in the article.
   run actual_test.py and get the results in Fig.3, Fig.4 and Table3 in the article.
